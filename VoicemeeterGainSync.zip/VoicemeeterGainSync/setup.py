from setuptools import setup

setup(
  name='voicemeeter',
  version='0.1',
  description='Voicemeeter Remote Python API',
  packages=['voicemeeter'],
  install_requires=[
    'toml'
  ]
)