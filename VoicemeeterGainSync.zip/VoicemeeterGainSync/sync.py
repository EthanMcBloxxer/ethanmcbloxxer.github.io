#!/usr/bin/env python
#coding:utf-8
# Author:  Sg4Dylan --<sg4dylan#gmail.com>
# Created: 12/24/2020

from ctypes import POINTER, cast
from comtypes import CLSCTX_ALL
from pycaw.pycaw import AudioUtilities, IAudioEndpointVolume
import voicemeeter
import time


vb_kind = 'banana' # target voicemeeter edition ('basic', 'banana' or 'potato')
ch_idx = 3         # target input device index (left to right, start with 0)
voicemeeter.launch(vb_kind)
devices = AudioUtilities.GetSpeakers()
interface = devices.Activate(
    IAudioEndpointVolume._iid_, CLSCTX_ALL, None)
volume = cast(interface, POINTER(IAudioEndpointVolume))


def get_system_volume():
    return volume.GetMasterVolumeLevelScalar()


with voicemeeter.remote(vb_kind) as vmr:
    last_vo = None
    while True:
        sys_vo = get_system_volume()
        vb_vo = max(min(round(sys_vo*72-60),72),-60)
        if vb_vo != last_vo:
            vmr.inputs[ch_idx].gain = vb_vo
            last_vo = vb_vo
        time.sleep(1)
 
